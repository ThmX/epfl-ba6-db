-- Compute which country in which Olympics has benefited the most from playing in front of the home crowd.

-- We did not find a way to do this one.